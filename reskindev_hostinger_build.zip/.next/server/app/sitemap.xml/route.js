var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__1-mupey._.js")
R.c("server/chunks/_20-c6tp._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_05l5km9.js")
R.m(83345)
module.exports=R.m(83345).exports
